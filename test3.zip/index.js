// DISCORD BOT

// Instalacion previa

// Public: 647730592309575690
// TOKEN: NjQ3NzMwNTkyMzA5NTc1Njkw.Xdj9Sg.4G_u2aEPy128GfbUHfkQuTxFn-g
// url bot: https://discordapp.com/api/oauth2/authorize?client_id=647730592309575690&permissions=8&scope=bot

// forever: https://stackoverflow.com/questions/12701259/how-to-make-a-node-js-application-run-permanently

const Discord = require('discord.js');
const ytdl = require('ytdl-core');
const client = new Discord.Client();

const botToken = 'NjUxODI3MDczODc4NTg5NDgw.XefjbA.GPdoaok1zdTtRJm9ZQ_MnVQpduE';
const botID = '651827073878589480';

// ID Exoust
const canal1ID = '554302023114162177'; // Ausencias general
const canal2ID = '651836489944137749'; // Ausencias ofi

//ID juanansal canal
//const canal1ID = '647734721555464202'; // DiscordBot
//const canal2ID = '618802485053751317'; // LUL

//ID dictadura
//const canal1ID = '651826907171782663'; // general ausencias
//const canal2ID = '651826943183945758'; // ofi ausencias

// Id Discord canal
//const canal1ID = '647734721555464202'; // DiscordBot
//const canal2ID = '618802485053751317'; // LUL

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', async msg => {

    console.log('ID: '+msg.channel.id);

    ////////////////////
    // Ausencias
    ////////////////////

    // Si mensaje enviado esta en el canal 1
    if(msg.channel.id == canal1ID) {
        if(msg.author.id != botID) {
            msg.delete(0)
            .then(msg => {
                console.log(`Deleted message from ${msg.author.username}`);
                msg.reply('Ausencia recibida');

                let nombreUsuario = msg.author.username;
                if(msg.member.nickname) {
                    nombreUsuario = msg.member.nickname;
                }
                client.channels.get(canal2ID).send(nombreUsuario+':  ' +msg.content);
                //console.log(msg.guild.roles);

            ///////////////////////////////////
            // TESTEO

            //var hereRole = msg.channel.server.roles.get('Dios', 'here');

            ///////////////////////////////////

            })
            .catch( (err) => {
                console.error(err);
            });
        }
        else {
            msg.delete(3000)
            .then(msg => {
                console.log(`Deleted message from ${msg.author.username}`);
            })
            .catch( (err) => {
                console.error(err);
            });
        }
    }

    //console.log(msg);
});



client.login(botToken);