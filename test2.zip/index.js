// DISCORD BOT

// Instalacion previa

// Public: 647730592309575690
// TOKEN: NjQ3NzMwNTkyMzA5NTc1Njkw.Xdj9Sg.4G_u2aEPy128GfbUHfkQuTxFn-g
// url bot: https://discordapp.com/api/oauth2/authorize?client_id=647730592309575690&permissions=8&scope=bot

// forever: https://stackoverflow.com/questions/12701259/how-to-make-a-node-js-application-run-permanently

const Discord = require('discord.js');
const ytdl = require('ytdl-core');
const client = new Discord.Client();

const botToken = 'NjQ3NzMwNTkyMzA5NTc1Njkw.Xdj9Sg.4G_u2aEPy128GfbUHfkQuTxFn-g';
const botID = '647730592309575690';

// ID EXODAR
//const canal1ID = '647770397668016139'; // Ausencias general
//const canal2ID = '215594550339567616'; // Ausencias general
//const canalMusic1ID = '245558017624506368'
//const canalMusic2ID = '393446292912734208'

// ID juanansal canal
const canal1ID = '647734721555464202'; // DiscordBot
const canal2ID = '618802485053751317'; // LUL
const canalMusic1ID = '647941923927228436'
const canalMusic2ID = '647941923927228436'

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', async msg => {

    console.log('ID: '+msg.channel.id);

    ////////////////////
    // Ausencias
    ////////////////////

    // Si mensaje enviado esta en el canal 1
    if(msg.channel.id == canal1ID) {
        if(msg.author.id != botID) {
            msg.delete(0)
            .then(msg => {
                console.log(`Deleted message from ${msg.author.username}`);
                msg.reply('Ausencia recibida');

                let nombreUsuario = msg.author.username;
                if(msg.member.nickname) {
                    nombreUsuario = msg.member.nickname;
                }
                client.channels.get(canal2ID).send(nombreUsuario+' --> ' +msg.content)

            })
            .catch( (err) => {
                console.error(err);
            });
        }
        else {
            msg.delete(5000)
            .then(msg => {
                console.log(`Deleted message from ${msg.author.username}`);
            })
            .catch( (err) => {
                console.error(err);
            });
        }
    }



    ////////////////////
    // YOUTUBE
    ////////////////////

    if (!msg.guild) return;

    if (msg.channel.id == canalMusic1ID || msg.channel.id == canalMusic2ID) {

        console.log('------------------------------');

        // Estas en el canal?
        if (msg.member.voiceChannel) {

            let mensaje = msg.content;

            let regex = /http(?:s?):\/\/(?:www\.)?youtu(?:be\.com\/watch\?v=|\.be\/)([\w\-\_]*)(&(amp;)?‌​[\w\?‌​=]*)?/;
            let link = msg.content;
            let res = regex.test(link);

            console.log('Link: '+ res);
            // Comprobar el link
            if(res) {
                console.log('PASA POR AQUI');
                const connection = await msg.member.voiceChannel.join();
                const dispatcher = connection.playStream(ytdl(link))
                .on("end",()=>{
                    console.log("Audio Terminado")
                    msg.member.voiceChannel.leave()
                })
            }

        // No esta en un canal de voz, mensaje de advertencia    
        }
    }


    //console.log(msg);
});



client.login(botToken);