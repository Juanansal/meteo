// DISCORD BOT

// Public: 647730592309575690
// TOKEN: NjQ3NzMwNTkyMzA5NTc1Njkw.Xdj9Sg.4G_u2aEPy128GfbUHfkQuTxFn-g
// url bot: https://discordapp.com/api/oauth2/authorize?client_id=647730592309575690&permissions=8&scope=bot

const Discord = require('discord.js');
const client = new Discord.Client();

const botToken = 'NjQ3NzMwNTkyMzA5NTc1Njkw.Xdj9Sg.4G_u2aEPy128GfbUHfkQuTxFn-g';
const botID = '647730592309575690';
const canal1ID = '647751041764556800';
const canal2ID = '215594550339567616';

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', msg => {

    console.log('ID: '+msg.channel.id);

    // Si mensaje enviado esta en el canal 1
    if(msg.channel.id == canal1ID ) {
        if(msg.author.id != botID) {
            msg.delete(0)
            .then(msg => {
                console.log(`Deleted message from ${msg.author.username}`);
                msg.reply('Ausencia recibida');
                client.channels.get(canal2ID).send(msg.author.username+' --> ' +msg.content)

            })
            .catch( (err) => {
                console.error(err);
            });
        }
        else {
            msg.delete(5000)
            .then(msg => {
                console.log(`Deleted message from ${msg.author.username}`);
            })
            .catch( (err) => {
                console.error(err);
            });
        }
    }


    

    
    //console.log(msg);
});



client.login(botToken);